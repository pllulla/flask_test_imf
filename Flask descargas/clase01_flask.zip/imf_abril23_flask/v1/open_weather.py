from flask import Blueprint, jsonify, request


open_weather = Blueprint('open_weather', __name__)

baseURL = '/v1/weather/'

@open_weather.route(baseURL + 'test', methods=['GET'])
def weather_test():
    
    return jsonify({'result': True, 'response': 'Este es mi primer endpoint con Flask'}), 200

@open_weather.route(baseURL + '7days/<_ciudad>', methods=['GET'])
def weather_7days(_ciudad):
    
    return jsonify({'result': True, 'response': _ciudad}), 200

@open_weather.route(baseURL + '7days', methods=['POST'])
def weather_7days_post():
    
    try:
        inData = request.get_json()
        
        if inData['ciudad'] == '':
            return jsonify({'result': False, 'response': 'Debe ingresar una ciudad'}), 400
        else:
            return jsonify({'result': True, 'response': inData['ciudad']}), 200
    except:
        return jsonify({'result': False, 'response': 'Peticion malformada'}), 400